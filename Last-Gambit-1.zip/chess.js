/*
 * This uses the chess.js library 
 and chessboardjs documentation:
 * https://github.com/jhlywa/chess.js
 * https://chessboardjs.com/
 */

//The Game Object that stores and runs the chess functions
const game = new Chess()

var logList= [] //["(Key: w = white| b = black| P = pawn| R = rook| N = knight|          B = bishop| Q = queen| K = king)", "\n\nHistory:"]
const log = ["(Key: w = white| b = black| P = pawn| R = rook| N = knight|          B = bishop| Q = queen| K = king)", "\n\nHistory:"]
var sourcePiece
var oldSquare
var newSquare
var oldS
var movingPiece
var newS
var check
var isTrue = false
var isClicked = false
var logLen = 0;
var turn = 0
var logTurn = 1
var board = null



//a9a9a9
//696969
function removeGreySquares() {
  $('#myBoard .square-55d63').css('background', '')
}
// shwoing a difference between each other sqaure
function greySquare(square) {
  
  if (clicks1 == 0 || clicks1 % 5 == 0) {
    var whiteSquareGrey = '#a9a9a9'
    var blackSquareGrey = '#696969'

  }
  else if (clicks1 % 5 == 1) {

    var whiteSquareGrey = '#fcb1f5'
    var blackSquareGrey = '#e37fd9'

  }
  else if (clicks1 % 5 == 2) {

    var whiteSquareGrey = '#b1d2fc'
    var blackSquareGrey = '#218cff'
  }
  else if (clicks1 % 5 == 3) {

    var whiteSquareGrey = '#4c9164'
    var blackSquareGrey = '#b3885d'
  }

  else if (clicks1 % 5 == 4) {

    var whiteSquareGrey = '#ab3933'
    var blackSquareGrey = '#3d2c16'
  };


  var $square = $('#myBoard .square-' + square)

  var background = whiteSquareGrey
  if ($square.hasClass('black-3c85d')) {
    background = blackSquareGrey
  }

  $square.css('background', background)
}

function onDragStart(source, piece) {

  sourcePiece = piece
  oldSquare = source

  if (click % 2 == 1) {
    return false
  }

  if (game.in_check() && isTrue == true) {
    return false
  }

  // do not pick up pieces if the game is over
  if (game.game_over()) {
    return false
  }
  // or if it's not that side's turn
  if ((game.turn() === 'w' && piece.search(/^b/) !== -1) ||
    (game.turn() === 'b' && piece.search(/^w/) !== -1)) {
    return false
  }
}

function onMouseoverSquare(square, piece) {
  // get list of possible moves for this square
  var moves = game.moves({
    square: square,
    verbose: true,
  })

  if (click % 2 == 1) {
    return false
  }

  if (game.game_over()) {
    return false
  }
  // exit if there are no moves available for this square
  if (moves.length === 0) return

  // highlight the square they moused over
  greySquare(square)


  // highlight the possible squares for this piece
  for (var i = 0; i < moves.length; i++) {
    greySquare(moves[i].to)
  }
}

//once mouse stops hovering over square the Grey Squares are removed
function onMouseoutSquare(square, piece) {
  removeGreySquares()
}
//After the player moves and the piece snaps the board updates to the new position
function onSnapEnd() {
  board.position(game.fen())
}

//When the board changes
function onChange(oldPos, newPos) {

console.log(game.history());

  /*
 SHOWS HISTORY
  */

  oldS = JSON.stringify(oldSquare)
  movingPiece = JSON.stringify(sourcePiece)
  newS = JSON.stringify(newSquare)

    /*if(isClicked)
    {
      //logList.pop()
      turn--
      logTurn -= .5
    }*/

  //Updates the Gamelog
  if (check !== oldS) {
    if (game.in_checkmate() && turn % 2 == 0) {
      /* 
      - Whites's Turn
      - White checkmates Black
      - Notifies user
      - Updates Log
      */
      logList.push("\n" + logTurn + ". " + movingPiece + " from " + oldS + " to " + newS)
      /** */
      document.getElementById('checkMate').style.display = 'block';
      document.getElementById('myBoard').style.opacity = '0.3';
      /** */
      //window.alert("White wins!!!" +     
      //"Feel free to go to the settings tab and click New Game to play again :)");
    }
    else if (game.in_checkmate() && turn % 2 == 1) {
      /*
      - Black's Turn
      - Black checkmates White
      - Notifies user
      - Updates Log
      */
      logList.push(movingPiece + " from " + oldS + " to " + newS + "\n")
      /** */
      console.log("BLACK CHECKMATE")
      /** */
      document.getElementById('checkMate').style.display = 'block';
      document.getElementById('myBoard').style.opacity = '0.3';
      /** */
      //window.alert("Black wins!!!" +     
      //"Feel free to go to the settings tab and click New Game to play again :)");

    }
    else if (game.in_stalemate()
      || game.in_threefold_repetition()
      || game.insufficient_material()
      || game.in_draw()
    ) {
      /*
        It's STALEMATE due to:
        - 3 turns to repeated moves
        - A player cannot move but King is not in check
        - It is impossible for either player to acheive a checkmate
      */
      document.getElementById('staleMate').style.display = 'block';
      document.getElementById('myBoard').style.opacity = '0.3';
    }
    else if (game.in_check() && turn % 2 == 0) {
      /*
      - White's Turn
      - A player is in check
      - No player is in checkmate
      */
      logList.push("\n" + logTurn + ". " + movingPiece + " from " + oldS + " to " + newS)
      /** */
      document.getElementById('myBoard').style.opacity = '0.3';
      document.getElementById('check-menu').style.display = 'block';
      /** */
      isTrue = true
      /** */
      let myTimer = setTimeout(checkTimer, 500);
      function checkTimer() {
        isTrue = false
        document.getElementById('myBoard').style.opacity = '1';
        document.getElementById('check-menu').style.display = 'none';
      }
    }
    else if (game.in_check() && turn % 2 == 1
      && game.in_checkmate() != true) {
      /*
      - Black's Turn
      - A player is in check
      - No player is in checkmate
      */
      logList.push(movingPiece + " from " + oldS + " to " + newS + "\n")
      /** */
      document.getElementById('myBoard').style.opacity = '0.3';
      document.getElementById('check-menu').style.display = 'block';
      /** */
      isTrue = true
      /** */
      let myTimer = setTimeout(checkTimer, 500);
      function checkTimer() {
        isTrue = false
        document.getElementById('myBoard').style.opacity = '1';
        document.getElementById('check-menu').style.display = 'none';
      }
    }
    else if (turn % 2 == 0 && game.in_check() != true) {
      /*
      - White's Turn
      - No player is in check
      - No player is in checkmate
      */
      logList.push("\n" + logTurn + ". " + movingPiece + " from " + oldS + " to " + newS)
    }

    else {
      /*
      - Black's Turn
      - No player is in check
      - No player is in checkmate
      */
      logList.push(movingPiece + " from " + oldS + " to " + newS + "\n")
    }
    turn++
    logTurn += .5
  }
  check = oldS

  log.splice(2,3)
  log.push(logList.join(" - "))
  $('#gameLog').text(log)
  isClicked = false
}



var config = {
  draggable: true,
  position: 'start',
  onChange: onChange,
  onDragStart: onDragStart,
  onDrop: onDrop,
  onMouseoutSquare: onMouseoutSquare,
  onMouseoverSquare: onMouseoverSquare,
  onSnapEnd: onSnapEnd,
}

var config1 = {
  draggable: false

}

var config2 = {
  draggable: true

}

//display the actual board in the website
board = Chessboard('myBoard', config)


var squareToHighlight = null
var $board = $('#myBoard')
var squareClass = 'square-55d63'

function onDrop(source, target) {
  // see if the move is legal
  var move = game.move({
    from: source,
    to: target,
    promotion: 'q'
  })
  newSquare = target
  // illegal move
  if (move === null) return 'snapback'

  function removeHighlights(color) {
    $board.find('.' + squareClass)
      .removeClass('highlight-' + color)
  }


  // highlight black's move
  removeHighlights('black')
  $board.find('.square-' + move.from).addClass('highlight-black')
  squareToHighlight = move.to
  // highlight white's move
  removeHighlights('white')
  $board.find('.square-' + source).addClass('highlight-white')
  $board.find('.square-' + target).addClass('highlight-white')

  function onMoveEnd() {
    $board.find('.square-' + squareToHighlight)
      .addClass('highlight-black')
  }

  backFunction.onclick = function () {
  $('#back-button').on('click', game.undo())
  $('#back-button').on('click', onSnapEnd())
  logList.pop()
  if(turn > 0){
  logTurn -= .5
  turn--
  }
  board.resize
  }
}
function newPage() {
  location.reload()
}

$('#flipBoard').on('click', board.flip)
$('#theme-menu').on('click', board.resize)
backFunction = document.getElementById("back-button");


volcano_color = ['#9E7863', '#633526'];
jungle_color = ['#EFEFEF', '#FFFFFF'];
original_color = ['#FFFFFF', '#E1E1E1'];
winter_color = ['#D18B47', '#FFCE9E'];
summer_color = ['#FFE5B6', '#B16228'];
// for the colors look at the old projects for all of the #'s